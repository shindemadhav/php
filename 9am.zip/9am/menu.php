<ul>
<li><a href="home.php">Home</a></li>
<li><a href="edit.php">Edit Profile</a></li>
<li><a href="change_pwd.php">Change Password</a>
</li>
<li><a href="upload_avatar.php">Upload Avatar</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
<?php 
if($row['profile_pic']!="")
{
?>
<Img src="profiles/<?php echo $row['profile_pic']?>" 
height="50" width="50">
<?php }?>