<html>
	<head>
		<title>File Uloading</title>
	</head>
	<body>
		<h1>File Uploading</h1>
		<?php 
		
		if(isset($_POST['submit']))
		{
			if(is_uploaded_file($_FILES['avatar']['tmp_name']))
			{
				$filename=$_FILES['avatar']['name'];
				$size=$_FILES['avatar']['size'];
				$type=$_FILES['avatar']['type'];
				$tmp=$_FILES['avatar']['tmp_name'];
				
				$ext=substr($filename,strpos($filename,"."));
				$chars="abcdefghijklmnopqrstuqvwxyz1234567890";
				$file_name=substr(str_shuffle($chars),10,10)."_".time().$ext;
				$arr=array("image/png","image/jpeg","image/jpg","image/gif");
				if(in_array($type,$arr))
				{
					if(move_uploaded_file($tmp,"uploads/$file_name"))
					{
						echo "File Uploads Successfully";
					}
					else
					{
						echo "Sorry! Unable To Upload";
					}
				}
				else
				{
					echo "Please Sleect Valid IMage";
				}
			}
			else
			{
				echo "Please select a File";
			}
		}
		?>
		
		<form method="POST" action="" enctype="multipart/form-data">
			<table>
				<tr>
					<td><label>Username</label></td>
					<td><input type="text" name="uname"></td>
				</tr>
				<tr>
					<td><label>Email</label></td>
					<td><input type="text" name="email"></td>
				</tr>
				<tr>
					<td><label>Password</label></td>
					<td><input type="password" name="password"></td>
				</tr>
				
				<tr>
					<td><label>UPload Avatar</label></td>
					<td><input type="file" name="avatar"></td>
				</tr>
				
				<tr>
					<td></td>
					<td><input type="submit" name="submit" 
					value="Register"></td>
				</tr>
			</table>
		</form>
	</body>
</html>