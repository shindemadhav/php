<?php
 $to="ram@mail.com";
 $subject="Activation Link";
 $message="Hi User,<br>Your account is created.please
 click the below link to activate your account<br>
 <a href=''>Activate Now</a><br><br>Thanks<br>Team";
 
 $headers="Content-Type:text/html" ."/r/n".
	"cc:Ram <ram@mail.com>" ."/r/n".
	"from: GoPHP <info@gophp.in>";
	
	echo mail($to,$subject,$message,$headers);
	
 ?>

	
	