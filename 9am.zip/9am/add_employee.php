<html>
	<head>
		<title>Add Employee</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<style>
		label.error{color:red;}
		</style>
		<link rel="stylesheet" href="css/jquery-ui.css">
		<script src="js/jquery-1.12.4.js"></script>
		<script src="js/jquery-ui.js"></script>
		<script src="js/jquery.validate.min.js"></script>
		 <script>
		  $( function() {
			$( "#datepicker" ).datepicker({
				yearRange: "1950:2007",
				changeMonth: true,
				changeYear: true,
				dateFormat:'yy-mm-dd'
			});
		  } );
		</script>
		
		
  
	</head>
	<body>
		<div class="container well">
			<div class="row">
				<h2>Add Employee</h2>
				<?php 
				if(isset($_COOKIE['success']))
				{
					echo "<p class='alert alert-success'>Employee Added Successfully</p>";
				}
				
				?>
				<?php 
				include("connect.php");//$con
				if(isset($_POST['add']))
				{
					$ename=filterFormData($_POST['ename']);
					$email=filterFormData($_POST['email']);
					$mobile=filterFormData($_POST['mobile']);
					$gender=filterFormData($_POST['gender']);
					$dob=filterFormData($_POST['dob']);
					$addr=filterFormData($_POST['address']);
					$city=filterFormData($_POST['city']);
					$state=filterFormData($_POST['state']);
					$pin=filterFormData($_POST['pincode']);
					if(is_uploaded_file($_FILES['image']['tmp_name']))
					{
						$filename=$_FILES['image']['name'];
						move_uploaded_file($_FILES['image']['tmp_name'],"employees/$filename");
					}
					else
					{
						$filename="";
					}
					
					$query="insert into employees(ename,email,mobile,
					gender,dob,address,city,state,pincode,image,
					date_of_join) values('$ename','$email','$mobile','$gender',
					'$dob','$addr','$city','$state','$pin','$filename',NOW())";
					
					mysqli_query($con,$query);
					
					if(mysqli_affected_rows($con)==1)
					{
						//echo mysqli_affected_rows($con);
						setcookie("success","1",time()+3);
						header("Location:add_employee.php");
					}
					
					//insert  employee in Db
				}
				
				function filterFormData($data)
				{
					if(!empty($data))
					{
						return addslashes(strip_tags(trim($data)));
					}
				}
				
				
				?>
				
				
				
				<form id="emp" action="" method="POST" enctype="multipart/form-data">
				
					<div class="col-md-6">
						<div class="form-group">
						 <label for="cname">Name (required, at least 2 characters)</label>
						<input id="cname" class="form-control" name="name" minlength="2" type="text" required>
						</div>
						
						<div class="form-group">
							<label>Email</label>
							<input id="email" type="email" class="form-control" name="email" required>
						</div>
						
						<div class="form-group">
							<label>Mobile</label>
							<input id="mobile" required minlength="10" maxlength="10" type="text" class="form-control" name="mobile">
						</div>
						
						<div class="form-group">
							<label>Gender:</label><br>
							<input id="gender" required type="radio" value="Male" name="gender">Male &nbsp;
							<input  type="radio" value="Female" name="gender">Female
						</div>
						
						<div class="form-group">
							<label>Date of Birth</label>
							<input  required type="text" id="datepicker" class="form-control" name="dob">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Address</label>
							<textarea  id="address" required class="form-control" name="address"></textarea>
						</div>
						
						<div class="form-group">
							<label>City</label>
							<input id="city" required type="text" class="form-control" name="city">
						</div>
						
						<div class="form-group">
							<label>State</label>
							<select id="state" required class="form-control" name="state">
								<option value=''>--Select State--</option>
								<option value='Andhrapradesh'>Andhrapradesh</option>
								<option value='Telangana'>Telangana</option>
								<option value='Odisha'>Odisha</option>
								<option value='West Bengal'>West Bengal</option>
								<option value='Maharastra'>Maharastra</option>
								<option value='Tamilnadu'>Tamilnadu</option>
							</select>
						</div>
						
						<div class="form-group">
							<label>Pincode</label>
							<input type="text" class="form-control" name="pincode">
						</div>
						
						<div class="form-group">
							<label>Upload Employee IMage</label>
							<input type="file" class="form-control" name="image">
						</div>
						

					</div><br><br>
						<div class="form-group">
							<input type="submit" class="btn btn-primary" name="add" value="Add Employee">
						</div>
				</form>
				
					<script>
						$("#emp").validate({
							rules:{
								ename:'required',
								email:{
									required:true,
									email:true,
								},
								mobile:{
									required:true,
									number:true,
								}
							}
						});
					</script>
				
			</div>
		</div>
	</body>
</html>