<?php 
session_start();
if(isset($_SESSION['loggedin_id']))
{
	include("connect.php");
	$uid=$_SESSION['loggedin_id'];
	$res=mysqli_query($con,"select *from register 
	where id=$uid");
	$row=mysqli_fetch_assoc($res);
	
	?>
		<html>
			<head>
				<title><?php echo ucfirst($row['username'])?>
				| Edit Profile</title>
				<link href="css/style.css" rel="stylesheet">
			</head>
			<body>
				<?php
					include("menu.php");
				?>
				<h1>Edit Profile - 
				<?php echo ucfirst($row['username'])?></h1>
				
				<?php 
				
				if(isset($_GET['status']))
				{
					echo "<p>Profile Updated Successfully</p>";
				}
				
				if(isset($_POST['update']))
				{
					$name=$_POST['uname'];
					$mobile=$_POST['mobile'];
					$dob=$_POST['dob'];
					$state=$_POST['state'];
					$city=$_POST['city'];
					$query="update register set username='$name',
					mobile='$mobile',city='$city',state='$state',
					dob='$dob' where id=$uid";
					mysqli_query($con,$query);
					if(mysqli_affected_rows($con)==1)
					{
						header("location:edit.php?status=true");
						
					}
					else
					{
						if(mysqli_errno($con)==0)
						{
							echo "<p>Please chnage some fields
							to update</p>";
						}
					}
				}
				?>
				
				
				
				<form action="" method="POST">
				<table>
					<tr>
						<td>Username</td>
						<td><Input type="text" name="uname" 
						value="<?php echo $row['username']?>"></td>
					</tr>
					<tr>
						<td>Mobile</td>
						<td><Input type="text" name="mobile" 
						value="<?php echo $row['mobile']?>"></td>
					</tr>
					<tr>
						<td>City</td>
						<td><Input type="text" name="city" 
						value="<?php echo $row['city']?>"></td>
					</tr>
					<tr>
						<td>State</td> 
					<td><select id="state" name="state">
						<option value=''>--Select State--</option>
						<option value='Andhrapradesh' 
						<?php if($row['state']=="Andhrapradesh") 
							echo "selected";?>>Andhrapradesh</option>
						<option value='Telangana' 
						<?php if($row['state']=="Telangana") 
							echo "selected";?>>Telangana</option>
						<option value='Odisha' <?php if($row['state']=="Odisha") echo "selected";?>>Odisha</option>
						<option value='West Bengal' <?php if($row['state']=="West Bengal") echo "selected";?>>West Bengal</option>
						<option value='Maharastra' <?php if($row['state']=="Maharastra") echo "selected";?>>Maharastra</option>
						<option value='Tamilnadu' <?php if($row['state']=="Tamilnadu") echo "selected";?>>Tamilnadu</option>
					</select></td>
					</tr>
					
					<tr>
						<td>DOB</td>
						<td><Input type="text" name="dob" 
						value="<?php echo $row['dob']?>"></td>
					</tr>
					
					<tr>
						<td></td>
						<td><Input type="submit" name="update" 
						value="Update"></td>
					</tr>
					
				</table>
				</form>
			</body>
		</html>
	<?php
}
else
{
	header("location:login.php");
}
?>