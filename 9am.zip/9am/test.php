<?php 
	$con=mysqli_connect("localhost","root","","9am") 
	or die("Unable to Connct");
	
	$result=mysqli_query($con,"select *from contact");
	echo "<pre>";
	$row=mysqli_fetch_assoc($result);
	print_r($row);
		
	$row=mysqli_fetch_row($result);
	print_r($row);
	
	$row=mysqli_fetch_array($result);
	print_r($row);
	
	$row=mysqli_fetch_object($result);
	print_r($row);
	
	
?>