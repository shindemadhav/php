-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2017 at 06:26 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `9amnew`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `viewData` ()  begin
select id,username,email,mobile from register;
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `mobile`, `email`, `city`, `message`) VALUES
(1, 'ram', 345345345, 'ram@gmail.com', 'Hyderabad', 'Hello'),
(2, 'hello', 23423423423, 'hello@mail.com', 'Chennai', 'Hello How  r u?'),
(3, 'naresh', 1212121212, 'naresh@mail.com', 'Chennai', 'Welcome'),
(4, 'koti', 2323232323, 'koti@mail.com', 'Delhi', 'Hello');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `nid` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(250) NOT NULL,
  `id` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`nid`, `category`, `title`, `description`, `filename`, `id`, `date`, `status`) VALUES
(1, 'Entertainment', 'This program is free software', 'This program is free software; you can redistribute it and/or modify it under the terms of thePHP and MYSQLpublished by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.\r\n\r\nThis program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details. ', 'accordion1.png', 8, '1503808578', 1),
(2, 'Sports', 'You should have received a copy', 'You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\r\nYou should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.', 'tab1.png', 8, '1503808737', 1),
(3, 'Entertainment', 'This program is distributed in the hope', 'This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.\r\n\r\nThis program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details. ', 'slider_one.jpg', 9, '1503809933', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `oid` int(11) NOT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`oid`, `pname`, `quantity`, `price`, `date`, `id`) VALUES
(1, 'Shirt', 1, 1200, '2017-08-31 00:00:00', 1),
(3, 'Jeans', 2, 5000, '2017-08-31 00:00:00', 9),
(4, 'Jeans', 2, 5000, '2017-08-31 00:00:00', 9);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `state` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `profile_pic` varchar(250) NOT NULL,
  `terms` int(11) NOT NULL,
  `date_of_reg` datetime NOT NULL,
  `ip` varchar(30) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `user_key` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `mobile`, `gender`, `state`, `dob`, `address`, `profile_pic`, `terms`, `date_of_reg`, `ip`, `status`, `user_key`) VALUES
(1, 'Ram', 'ram@gmail.com', '202cb962ac59075b964b07152d234b70', '8446876117', 'Male', 'Andhrapradesh', '1987-07-25', '								Maithrivanam', '1505033955_ndbzq3xysj.jpeg', 1, '2017-08-21 10:28:31', '::1', 1, 'a894d70135d0d5d08af2522c59e20630'),
(2, 'koti', 'koti123@gmail.com', '202cb962ac59075b964b07152d234b70', '8446876117', 'Male', 'Andhrapradesh', '1987-07-25', 'Maithrivanam', '1503803925_2esnj1tn4o.jpeg', 1, '2017-08-21 10:34:14', '::1', 0, 'b3d04bca5c94b5799b2d00fec444e35c'),
(5, 'naresh', 'naresh@mail.com', '202cb962ac59075b964b07152d234b70', '8446876117', 'Male', 'Andhrapradesh', '1987-07-25', 'Maithrivanam', '1503803925_2esnj1tn4o.jpeg', 1, '2017-08-21 10:46:56', '::1', 0, '3604a8b11a5215a0c115983d65d9c86f'),
(7, 'siva', 'siva@gmail.com', '202cb962ac59075b964b07152d234b70', '8446876117', 'Female', 'Telangana', '1987-07-25', 'qweqw', '1503803925_2esnj1tn4o.jpeg', 1, '2017-08-21 11:00:23', '::1', 1, 'fe114098f1d66e5a95cdacbcd6fbf921'),
(8, 'lakshmi', 'lakshmi@mail.com', '81dc9bdb52d04dc20036dbd8313ed055', '234523432432', 'Female', 'Maharastra', '1987-07-25', '																SR NAgar', '1504760677_08xe4bman2.jpeg', 1, '2017-08-23 09:24:52', '::1', 1, '71eacdbc2213a0baf5722832ab078ec3'),
(9, 'boss', 'boss@mail.com', '202cb962ac59075b964b07152d234b70', '844681324234', 'Male', 'Maharastra', '1987-07-25', 'e', '1503803925_2esnj1tn4o.jpeg', 1, '2017-08-23 09:43:33', '::1', 1, '543755e0d616c09bbfbb84d92aca1bfc');

-- --------------------------------------------------------

--
-- Stand-in structure for view `regview`
--
CREATE TABLE `regview` (
`id` int(11)
,`username` varchar(100)
,`email` varchar(150)
,`mobile` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `username`, `email`, `password`, `date`, `ip`) VALUES
(1, 'Ram', 'ram@gmail.com', '202cb962ac59075b964b07152d234b70', '2017-08-20 08:33:23', '::1'),
(2, 'koti', 'koti123@gmail.com', '202cb962ac59075b964b07152d234b70', '2017-08-20 08:37:23', '::1'),
(3, 'naresh', 'sri@gmail.com', '202cb962ac59075b964b07152d234b70', '2017-08-20 08:40:48', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `state` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state`, `district`) VALUES
(1, 'Andhrapradesh', 'Prkasam'),
(2, 'Andhrapradesh', 'Guntur'),
(3, 'Andhrapradesh', 'Krishna'),
(4, 'Andhrapradesh', 'Nellore'),
(5, 'Telangana', 'Warangal'),
(6, 'Telangana', 'Hyderabad'),
(7, 'Telangana', 'Khammam'),
(8, 'Telangana', 'Nalgonda'),
(9, 'Maharastra', 'Pune'),
(10, 'Maharastra', 'Latur'),
(11, 'Maharastra', 'Mumbai'),
(12, 'Maharastra', 'Nanded'),
(13, 'WestBengal', 'Kolkata'),
(14, 'Tamilnadu', 'Salem'),
(15, 'Tamilnadu', 'Coimbatore'),
(16, 'Tamilnadu', 'Erode'),
(17, 'Uttarapradesh', 'Ghorakpur');

-- --------------------------------------------------------

--
-- Stand-in structure for view `xyz`
--
CREATE TABLE `xyz` (
`id` int(11)
,`username` varchar(100)
,`oid` int(11)
,`pname` varchar(100)
);

-- --------------------------------------------------------

--
-- Structure for view `regview`
--
DROP TABLE IF EXISTS `regview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `regview`  AS  select `register`.`id` AS `id`,`register`.`username` AS `username`,`register`.`email` AS `email`,`register`.`mobile` AS `mobile` from `register` ;

-- --------------------------------------------------------

--
-- Structure for view `xyz`
--
DROP TABLE IF EXISTS `xyz`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `xyz`  AS  select `register`.`id` AS `id`,`register`.`username` AS `username`,`orders`.`oid` AS `oid`,`orders`.`pname` AS `pname` from (`register` join `orders`) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `nid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`id`) REFERENCES `register` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
