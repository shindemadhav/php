<?php 
/*$arr=array();
$arr[]=20;
$arr[]=30;
$arr[]=40;
echo "<pre>";
print_r($arr);
*/




?>
