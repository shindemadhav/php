<html>
	<head>
		<title>Registeration</title>
		
		<script>
			function validate()
			{
				if(document.getElementById("uname").value=="")
				{
					alert("Enter Username");
					return false;
				}
				if(document.getElementById("email").value=="")
				{
					alert("Enter Email");
					return false;
				}
				if(document.getElementById("pwd").value=="")
				{
					alert("Enter Password");
					return false;
				}
				if(document.getElementById("cpwd").value=="")
				{
					alert("Enter Confirm Password");
					return false;
				}
				if(document.getElementById("pwd").value != 
				document.getElementById("cpwd").value)
				{
					alert("Passwords DOes not Match");
					return false;
				}
				
			}
		</script>
		
	</head>
	<body>
		<h1>Register Here</h1>
		
		<?php 
		include("connect.php");
		
		if(isset($_POST['submit']))
		{
			$name=mysqli_real_escape_string($con,$_POST['uname']);
			$email=mysqli_real_escape_string($con,$_POST['email']);
			$pwd=md5($_POST['pwd']);
			$mobile=$_POST['mobile'];
			$dob=$_POST['dob'];
			$gender=$_POST['gender'];
			$state=$_POST['state'];
			$city=$_POST['city'];
			$address=$_POST['address'];
			$terms=$_POST['terms'];
			date_default_timezone_set("Asia/Calcutta");
			$date_reg=date("Y-m-d h:i:s");
			$ip=$_SERVER['REMOTE_ADDR'];
			$key="123456789abcdefghijklmnopqrstuv
			wxyz".$email.$dob.$mobile;
			$uq=md5(substr(str_shuffle($key),10,10));
			
			$query="insert into register(username,email,password,
			mobile,dob,state,city,address,gender,terms,ip,date_of_reg,
			unique_key) values('$name','$email','$pwd','$mobile',
			'$dob','$state','$city','$address','$gender','$terms',
			'$ip','$date_reg','$uq')";
			mysqli_query($con,$query);
			if(mysqli_affected_rows($con)==1)
			{
				//
				$to=$email;
				$subject="Account Activation LInk-GoPHP";
				$message="Hi ".$name.",<br><br>Thanks For registring with
				gophp.Your account detaisl are:<br><br>Username:Your Mail
				<br>Password:".$_POST['pwd']."<br><br>To get Access with 
				our servives from our website, Please activate your 
				account.<br><br>
				<a href='http://localhost:8080/9am/activate.php?uid=".$uq."' 
				target='_blank'>Activate Now</a>
				<br><br>Thanks<br>GoPHP";
				$headers="Content-Type:text/html";
				if(mail($to,$subject,$message,$headers))
				{
					echo "<p>Account CReated Successfully. 
					PLease Activate Your Account</p>";
				}
				else
				{
					echo "<p>Sorry! Unable to Send an Email.</p>";
					
				}
			}
			else
			{
				echo "<p>Sorry! Unable to Create 
				Account!.".mysqli_error($con)."</p>";
			}
			
				
		}
		?>
		
		
		<form method="POST" action="" onsubmit="return validate()">
			<table>
				<tr>
					<td>Username*</td>
					<td><input type="text" name="uname" id="uname"></td>
				</tr>
				<tr>
					<td>Email*</td>
					<td><input type="text" name="email" id="email"></td>
				</tr>
				<tr>
					<td>Password*</td>
					<td><input type="password" name="pwd" id="pwd"></td>
				</tr>
				<tr>
					<td>Confirm Password*</td>
					<td><input type="password" name="cpwd" id="cpwd"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" id="mobile"></td>
				</tr>
				<tr>
					<td>DOB</td>
					<td><input type="text" name="dob" id="dob"></td>
				</tr>
				
				<tr>
					<td>Gender</td>
					<td><input type="radio" name="gender" value="Male">Male 
					&nbsp;
					<input type="radio" name="gender" value="Female">Female
					
					</td>
				</tr>
				
				<tr>
					<td>State</td>
					<td><select id="state" name="state">
						<option value=''>--Select State--</option>
						<option value='Andhrapradesh'>Andhrapradesh</option>
						<option value='Telangana'>Telangana</option>
						<option value='Odisha'>Odisha</option>
						<option value='West Bengal'>West Bengal</option>
						<option value='Maharastra'>Maharastra</option>
						<option value='Tamilnadu'>Tamilnadu</option>
					</select></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input type="text" name="city" id="city"></td>
				</tr>
				<tr>
					<td>Address</td>
					<td><textarea name="address" id="address"></textarea></td>
				</tr>
				
				<tr>
					<td></td>
					<td><input type="checkbox" name="terms" id="terms" 
					value='1'> Please accept Terms and Conditions</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" value="Register"></td>
				</tr>
				
				
			</table>
		</form>
		
	</body>
</html>