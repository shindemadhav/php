<?php 

echo $_COOKIE['number1'];
echo $_COOKIE['number2'];


/*$arr=array("madam","did","hello","liril","php","ram","mysql");
$c=count($arr);
for($j=0;$j<$c;$j++)
{
	$str=$arr[$j];
	$k=0;
	for(;@$str[$k]!="";)
	{
		$k++;
	}

	$s="";
	for($i=$k-1;$i>=0;$i--)
	{
		$s.=$str{$i};
	}

	if($s==$arr[$j])
	{
		echo $arr[$j];
		echo "<br>";
	}
}
print_r($arr);
*/
/*$arr=array("Hello","Bye","Good",2=>"Bye");
echo "<pre>";
print_r($arr);
*/

/*
$arr=array(
	1=>10,
	true=>20,
	"1"=>30,
);
echo "<pre>";
print_r($arr[1]);//30
*/
/*
$arr=array(16=>100,200,11=>300,400);
echo "<pre>";
print_r($arr);
*/

?>