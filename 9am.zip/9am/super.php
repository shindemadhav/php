<?php 
function add()
{
	$x=200;
	$y=300;
	$z=$x+$y;
	echo "The Sum is:".$z;
}


?>
	