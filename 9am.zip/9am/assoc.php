<?php 

$arr=array(
	array("Ram","Naresh","suresh"),
	array(10,20,30,40),
	array(100,200,300,400,500),
	array("K","L","M","N")
);

$c=count($arr);
echo "<ul type='circle'>";
for($i=0;$i<$c;$i++)
{
	for($k=0;$k<count($arr[$i]);$k++)
	{
		echo "<li>".$arr[$i][$k]."</li>";
		
	}
}
echo "</ul>";

/*
$address=array(
	"street"=>"Shivbagh",
	"area"=>"Ameerpet",
	"state"=>"TS",
	"city"=>"Hyderabad",
);
foreach($address as $value=>$key)
{
	echo $value."=".$key;
	echo "<br>";
}
*/







?>