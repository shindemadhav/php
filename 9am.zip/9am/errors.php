<?php 

function add()
{
	echo "This is add";
}
add();
add1();
add();
?>