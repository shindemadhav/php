-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2017 at 06:10 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `9am`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `city`, `mobile`, `message`) VALUES
(1, 'ram', 'ram@mail.com', 'Hyderabad', 7894569871, 'Hello World'),
(2, 'Koti', 'koti@mail.com', 'Hyderabad', 7897894561, 'Hi Welcome'),
(3, 'Suresh', 'suresh@mail.com', 'Chennai', 45698745621, 'Hello World'),
(4, 'Naresh', 'naresh@mail.com', 'Chennai', 7898789466, 'gfd'),
(5, 'hello', 'hello@mail.com', 'Chennai', 2423423423, 'erterter'),
(6, 'koti', 'koti@mail.com', 'chennai', 23423423, 'hi'),
(7, 'koti', 'koti@mail.com', '', 0, ''),
(8, 'xyz', 'xyz@mail.com', '', 0, 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `eid` int(11) NOT NULL,
  `ename` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `image` varchar(100) NOT NULL,
  `date_of_join` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`eid`, `ename`, `email`, `mobile`, `gender`, `dob`, `address`, `city`, `state`, `pincode`, `image`, `date_of_join`, `status`) VALUES
(1, 'Ram', 'ram@mail.com', '9885776740', 'Male', '0000-00-00', '', 'Hyderabad', 'Telangana', '500038', 'NOW()', '0000-00-00 00:00:00', 'Active'),
(2, 'koti', 'koti@mil.com', '9885776740', 'Male', '0000-00-00', 'asdasd', 'Hyderabad', 'Andhrapradesh', '500038', 'img1.png', '2017-11-06 10:51:24', 'Active'),
(3, 'naresh', 'naresh@mail.com', '9885776740', 'Male', '2015-10-10', 'Hyd', 'Hyderabad', 'Telangana', '500038', 'bg2.jpg', '2017-11-07 09:23:38', 'Active'),
(4, 'suresh', 'suresh@mail.com', '9885776740', 'Male', '2015-10-10', 'sdfd', 'Hyderabad', 'Andhrapradesh', '500038', 'bg1.jpg', '2017-11-07 09:25:25', 'Active'),
(5, 'siva', 'siva@mail.com', '9885776740', 'Male', '2015-10-10', 'sd', 'Hyderabad', 'Odisha', '500038', 'bg3.jpg', '2017-11-07 09:27:34', 'Active'),
(6, 'lakshmi', 'lakshmi@mail.com', '9885776740', 'Female', '2015-10-10', 'asd', 'Hyderabad', 'Telangana', '500038', 'img3.png', '2017-11-07 09:31:17', 'Active'),
(9, '', '', '', '', '0000-00-00', '', '', '', '', '', '2017-11-07 09:33:26', 'Active'),
(16, '', 'ramu@mail.com', '3242342342', 'Female', '2017-11-23', 'adsffsd', 'Hyderabad', 'Andhrapradesh', '500038', '', '2017-11-07 10:27:53', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `terms` int(11) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `date_of_reg` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `unique_key` varchar(32) NOT NULL,
  `profile_pic` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `mobile`, `dob`, `state`, `city`, `address`, `gender`, `terms`, `ip`, `date_of_reg`, `status`, `unique_key`, `profile_pic`) VALUES
(1, 'ram', 'ram@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '9985591242', '1987-07-25', 'Andhrapradesh', 'Hyderabad', 'Maithrivanam', 'Male', 1, '::1', '2017-10-29 08:19:03', 1, '69055c06eb072c6ad33c5b503f758b11', ''),
(4, 'koti', 'koti123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '8446876117', '1987-07-25', 'Telangana', 'Hyderabad', 'Maithrivanam', 'Male', 1, '::1', '2017-10-29 08:27:37', 0, '6b66dbfe239382c63855a55701dd417a', ''),
(5, 'naresh', 'naresh@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '8446876117', '1987-07-25', 'Andhrapradesh', 'Hyderabad', 'Maithrivanam', 'Male', 1, '::1', '2017-10-29 08:37:44', 0, 'dcd573f1de24593c02433fde0ff8364c', ''),
(6, 'ravi kumar', 'ravi@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '9885774105', '1987-07-25', 'Telangana', 'Hyderabad', 'Hyd', 'Male', 1, '::1', '2017-10-29 08:41:47', 1, 'fc3994810ca422eecb07b3105f4e5400', '4can78kw9x_1509685789.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`eid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
