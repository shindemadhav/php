<?php

if(isset($_REQUEST['uid']))
{
	$uid=$_REQUEST['uid'];
	include("connect.php");
	$res=mysqli_query($con,"select *from register where 
	unique_key='$uid'");
	if(mysqli_num_rows($res)==1)
	{
		mysqli_query($con,"update register set status=1 
		xzwhere unique_key='$uid'");
		if(mysqli_affected_rows($con)==1)
		{
			echo "Account Activated Successfully";
		}
		else
		{
			echo "Account Activated Already";
		}
	}
	else
	{
		echo "<p>Sorry! We are unable to Update</p>";
	}
	
}
else
{
	echo "Sorry Wroing Window";
}

?>
