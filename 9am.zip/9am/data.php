<?php 

$x=123.123;
$x=(int)$x;
echo is_int($x);//1
echo "<br>";
echo "Value of x is:".$x;//1

$x;


?>

