<?php 
//header("location:http://localhost:8080/ciapp/");
header("Content-Disposition:attachement;filename=".time().".php");
readfile("header.php");
?>



