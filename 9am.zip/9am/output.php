<?
const name="Ram";
const subject="PHP";
echo name,subject;
?>


