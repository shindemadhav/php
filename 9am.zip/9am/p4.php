<?php 
session_start();
$p1=$_SESSION['number1'];
$p2=$_SESSION['number2'];
$p3=$_POST['num3'];

$sum=$p1+$p2+$p3;

echo "The Sum Is:".$sum;

?>
	