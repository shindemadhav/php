<?php

Looping Statements:

For
while
do while
foreach


/*
$x=(10>10 && 100>=200) ? 10 : 30;
echo $x;
*/

/*$m=95;
if($m>=90)
{
	echo "Grade A";
}
else if($m>=80)
{
	echo "Grade B";
}
else if($m>=70)
{
	echo "Grade C";
}
else if($m>=60)
{
	echo "Grade D";
}
else
{
	echo "Fail";
}
*/
?>
 
 
 
 
 
 
 
 
 