<?php echo "Standard Tag";?>

<? echo "Short open tag";?>

<% echo "this is ASP Tags"; %>

<script language="PHP">
	echo "I am Script Tag";
</script>