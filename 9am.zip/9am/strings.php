<!--<script>
document.addEventListener("keyup",function(event){
	alert(event.which)
})
</script>-->

<pre>
<?php 

$name="           ram    Babburi           ";
echo ltrim($name);

//echo htmlentities("<h1>Hello</h1>");//<h1>Hello</h1>

//$name="Ram\'s";
//echo addslashes($name);//Ram\'s
//echo stripslashes($name);

//echo htmlspecialchars("<h1>Hello</h1>");


//echo htmlspecialchars("<h1>Hello</h1>");


/*$str="&lt;h1&gt; Hello &lt;h1&gt";
echo htmlspecialchars_decode($str);
*/


//ECHO CHR(123);
//echo "<input type=\"text\" name='uname'>";

/*$str="this is Java Class";
echo str_replace("java","PHP",$str);
echo "<br>";
echo str_ireplace("JAVa","PHP",$str);
*/

//echo ord("a");//97


/*$str="Welcome to PHP Class";
echo str_word_count($str);
*/

/*
$str="10#20#30#40#50";
$arr=explode("#",$str);
print_r($arr);
*/

/*$arr=array(10,20,30,40,50);
echo implode("#",$arr);
*/



/*$str="Hello";
echo str_shuffle($str);


//generating OTP
$str="1234567890".time();
echo substr(str_shuffle($str),0,6);

*/

/*
$str="This program is free software";
echo substr($str,0,10)."...";
*/
/*$email="ram@gmail.com";
echo strpos($email,"A");//empty
echo strpos($email,"a");//1
echo stripos($email,"COM");//10
echo stripos($email,"com");//10
*/
//echo password_hash("ram@123",1);

/*$pwd="ram@123";
echo base64_encode($pwd);//cmFtQDEyMw==
echo base64_decode("cmFtQDEyMw==");//ram@123
*/

//encryption and decryption

/*
$pwd="23432ra";
echo crc32($pwd);*/
//echo sha1($pwd);//40 chars alpha-numeric
//echo md5($pwd);


/*$str="<h1 style='color:red'>RAM BABBBURI</h1>";
echo strip_tags($str);
*/

/*$name="RaM bAbBuRi";
echo ucwords(strtolower($name));
*/

//Ram Babburi Hello Welcome
//echo ucfirst($name);//Ram babburi
//echo strtoupper($name);//RAM BABBURI


/*
$str="Welcome to PHP";
echo strlen($str);
*/

/*//nowdoc string declaration (5.3 onwords)
$x=100;
$str= <<< "A"
Welcome $x
A;
echo $str;
*/

?>