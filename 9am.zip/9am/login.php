<?php session_start(); ?>
<html>
	<head>
		<title>Login Here</title>
		<script>
			function validate()
			{
				if(document.getElementById("email").value=="")
				{
					alert("Enter EMail");
					return false;
				}
				if(document.getElementById("pwd").value=="")
				{
					alert("Enter Password");
					return false;
				}
			}
		</script>
	</head>
	<body>
		<h1>Login Here</h1>
		
		<?php 
		include("connect.php");
		if(isset($_POST['login']))
		{
			$email=mysqli_real_escape_string($con,$_POST['email']);
			$pwd=mysqli_real_escape_string($con,md5($_POST['pwd']));
			
			$res=mysqli_query($con,"select *from register 
			where email='$email' and password='$pwd'");
			if(mysqli_num_rows($res)==1)
			{
				$row=mysqli_fetch_assoc($res);
				if($row['status']==1)
				{
					$_SESSION['loggedin_id']=$row['id'];
					$_SESSION['loggedin_email']=$row['email'];
					header("Location:home.php");
				}
				else
				{
					echo "<p>Please Activate your Account</p>";
				}
			}
			else
			{
				echo "<p>Sorry! Wrong Credentials</p>";
			}
		}
		?>
		
		
		<form method="POST" action="" onsubmit="return validate()">
			<table>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="pwd" id="pwd"></td>
				</tr>
				<tr>
					<td></td>
				<td><input type="submit" name="login" value="Login"></td>
				</tr>
			</table>
		</form>
	</body>
</html>