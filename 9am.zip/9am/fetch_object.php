<html>
	<head>
		<title>Contact List</title>
		<style>
			table{
				background:#d4d4d4;
			}
		</style>
		
	</head>
	<body>
		<h1>Contact List</h1>
		<?php 
		$con=mysqli_connect("localhost","root","","9am") 
		or die("Sorry! Unable to Connect");
		
		$result=mysqli_query($con,"select *from contact");
		if(mysqli_num_rows($result))
		{
			?>
				<table border=1>
					<tr>
						<th>Id</th>
						<th>Name</th>
						<th>Email</th>
						<th>City</th>
						<th>Mobile</th>
						<th>Message</th>
					</tr>
					<?php 
					while($row=mysqli_fetch_object($result))
					{
						?>
						<tr>
							<td><?php echo $row->id; ?></td>
							<td><?php echo $row->name; ?></td>
							<td><?php echo $row->email; ?></td>
							<td><?php echo $row->city; ?></td>
							<td><?php echo $row->mobile; ?></td>
							<td><?php echo $row->message; ?></td>
							
						</tr>
						<?php
					}
					?>
				</table>
			<?php
		}
		else
		{
			echo "<p>Sorry! No Records Found</p>";
		}
		?>
	</body>
</html>