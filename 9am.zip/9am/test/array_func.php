<?php 

$arr=array(
	array("state"=>"AP","country"=>"IND",30),
	array(100,200,300),
	100,
	200,
	300,
	400);
foreach($arr as $v)
{
	if(is_array($v))
	{
		foreach($v as $val)
		{
			echo $val;
			echo "<br>";
		}
	}
	else
	{
		print_r($v);
		echo "<br>";
	}
}





/*
$arr=array(array(10,20,30),array(100,200,300),100,200,300,400);
for($i=0;$i<count($arr);$i++)
{
	if(is_array($arr[$i]))
	{
		$c=count($arr[$i]);
		for($k=0;$k<$c;$k++)
		{
			echo $arr[$i][$k];
			echo "<br>";
		}
	}
	else
	{
		echo $arr[$i];
		echo "<br>";
	}
	
}
*/
/*
$arr=array(10,20,30,40,50,60,70,80,90,100);
array_splice($arr,2,0,25);
echo "<pre>";
print_r($arr);
*/
/*$arr=array(10,20,30,40,50,60,70,80,90,100);
$x=200;
echo is_array($x);
*/

/*$fa=array_slice($arr,2,2);
echo "<pre>";
print_r($fa);
*/

/*$arr=array(1,2,3,45,6,7,8,34,21,76,56,462);
shuffle($arr);
print_r(current($arr));
*/
/*
$arr=array(10,20,30,40,50);
echo next($arr);//20
echo prev($arr);//10
echo end($arr);//50
*/

//echo rand();
/*$arr=array(10,20,30,40,50);
shuffle($arr);
print_r($arr);//shuffled array
*/
/*
$arr=array(10,20,30,10,30,40,60,1,2,1,2,1,2);
$a1=array_unique($arr);
echo "<pre>";
print_r($a1);
*/

/*$arr=array(10,20,30,40);
echo array_key_exists(1,$arr);
*/
/*
$arr=array(10,20,30,40);
$x=200;
if(in_array($x,$arr))
{
	
	$pos=array_search($x,$arr);
	unset($arr[$pos]);
	echo "<pre>";
	print_r($arr);
	echo $x." is Deleted From array";
}
else
{
	echo $x." is not Found";
}
*/

/*
unset($arr[2]);
echo "<pre>";
print_r($arr);

*/



/*
$a1=array(10,20,30,40);
$a2=array(100,200,300,400);
$a3=array("a","v","v","b");

$fa=array_merge($a2,$a1,$a3);

echo "<pre>";
print_r($fa);
*/



/*$arr=array(false,true);
echo array_sum($arr);//21.5
echo array_product($arr);//0
*/

/*
$arr=array(
	"street"=>"Shivbagh",
	"area"=>"Ameerpet",
	"state"=>"TS",
	"city"=>"Hyderabad",
);
krsort($arr);
echo "<pre>";
print_r($arr);
*/
?>