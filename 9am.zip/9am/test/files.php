<?php 

opendir("");

/*$folder="css";
if(file_exists($folder))
{
	rmdir($folder);
	echo $folder." is Deleted";
}
else
{
	echo $folder." dores not Exists";
}
*/


//creatinga file in desktop
//$fp=fopen("C:/Users/PHP/Desktop/ram.txt","w");
//echo fwrite($fp,"welcome to php");



//echo strlen(file_get_contents("Chrysanthemum.jpg"));


/*$fp=fopen("welcome.html","w");
echo fwrite($fp,"Welcome to php classes"); 
*/

/*
$file="welcome.txt";
if(file_exists($file))
{
	unlink($file);
	echo $file." Deleted Successfully";
}
else
{
	echo $file." Does not exists";
}
*/
//echo file_exists("css");//folder //1
//echo file_exists("hi.txt");//file //1


/*echo is_file("hi.txt");//1
echo is_dir("css");//1
*/

//date_default_timezone_set("Asia/Calcutta");
//echo date("l,Y-m-d h:i:s A",fileatime("files.php"));
//echo date("l,Y-m-d h:i:s A",filemtime("files.php"));



//echo date("l,Y-m-d h:i:s A",filectime("ram.txt"));
//dfgdfgdfg
//echo file_get_contents("ram.txt");
//echo readfile("ram.txt");//ram3

//echo file_put_contents("ram.txt","Welcome php");

/*echo file_get_contents("welcome.txt");

echo file_get_contents("https://facebook.com");

echo file_get_contents("php://input");
*/

/*$fp=fopen("http://localhost:8080/ciapp/","r");
echo fread($fp,10000);
*/




/*$fp=fopen("welcome.txt","r+");
echo fwrite($fp,"php traiing ");
*/






//echo fread($fp,filesize("welcome.txt"));


//echo fread($fp,1000);
/*
echo filesize("hi.txt");//164

$fp=fopen("hi.txt","r");
echo fread($fp,filesize("hi.txt"));

fclose($fp);
echo fread($fp,filesize("hi.txt"));
*/




?>
