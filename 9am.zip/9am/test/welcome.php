<html>
	<head>
		<title>PHP</title>
	</head>
	<body>
		<?php echo "Hello World";?>
		<h1><?php echo "PHP Training";?></h1>
		<?php echo "<h3>Naresh Institute</h3>";?>
		Username:
		<input type="text" 
		value="<?php echo "Ram"; ?>">
		
	</body>
</html>

