<?php 

$x=200;
$y=500;
$z=$x+$y;

echo "The sum of ".$x." and ".$y." is:".$z;
 
//echo 'The sum of ' .$x. ' and ' .$y. ' is:'.$z;
	
?>




