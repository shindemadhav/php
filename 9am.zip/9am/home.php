<?php 
session_start();
if(isset($_SESSION['loggedin_id']))
{
	include("connect.php");//$con
	$uid=$_SESSION['loggedin_id'];
	$result=mysqli_query($con,"select *from 
	register where id=$uid");
	$row=mysqli_fetch_assoc($result);
	
	?>
		<html>
			<head>
				<title>Welcome to 
	<?php echo ucfirst($row['username']);?>!</title>
				<link href="css/style.css" rel="stylesheet">
			</head>
			<body>
			<?php
					include("menu.php");
				?>
				<h1>Welcome to 
				<?php echo ucfirst($row['username']);?>!</h1>
				<table id="customers">
					<tr>
						<td>Name</td>
					<td><?php echo ucfirst($row['username']);?></td>
					</tr>
					<tr>
						<td>Email</td>
						<td><?php echo $row['email']?></td>
					</tr>
					<tr>
						<td>MObile</td>
						<td><?php echo $row['mobile']?></td>
					</tr>
					<tr>
						<td>City</td>
						<td><?php echo $row['city']?></td>
					</tr>
					<tr>
						<td>State</td>
						<td><?php echo $row['state']?></td>
					</tr>
					<tr>
						<td>DoB</td>
						<td><?php echo $row['dob']?></td>
					</tr>
					<tr>
						<td>Gender</td>
						<td><?php echo $row['gender']?></td>
					</tr>
					<tr>
						<td>date of Reg</td>
						<td>
						<?php echo date("l,dS F Y, h:i:s A",
						strtotime($row['date_of_reg']));?></td>
					</tr>
				</table>
			</body>
		</html>
	<?php
}
else
{
	header("Location:login.php");
}

?>