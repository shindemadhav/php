<?php 

//echo $_SERVER['PHP_SELF'];// 9am/server.php
//echo $_SERVER['SCRIPT_NAME'];
//echo $_SERVER['SCRIPT_FILENAME'];
//echo $_SERVER['DOCUMENT_ROOT'];
//echo $_SERVER['SERVER_SOFTWARE'];
//echo $_SERVER['SERVER_NAME'];//localhost
//echo $_SERVER['SERVER_PORT'];//8080
//echo $_SERVER['REMOTE_ADDR'];

//echo $_SERVER['SERVER_PROTOCOL'];

echo $_SERVER['REQUEST_METHOD'];


?>