<?php 
session_start();
if(isset($_SESSION['loggedin_id']))
{
	include("connect.php");
	$uid=$_SESSION['loggedin_id'];
	$res=mysqli_query($con,"select *from register 
	where id=$uid");
	$row=mysqli_fetch_assoc($res);
	//print_r($row);
	?>
		<html>
			<head>
				<title><?php echo ucfirst($row['username']);?> 
				| Change Password</title>
				<link href="css/style.css" rel="stylesheet">
			</head>
			<body>
				<?php include("menu.php");?>
				<h1>Change Password - 
				<?php echo ucfirst($row['username']);?>!</h1>
				
				<?php 
				if(isset($_POST['update']))
				{
					$opwd=md5($_POST['opwd']);
					$npwd=md5($_POST['npwd']);
					$cnpwd=md5($_POST['cnpwd']);
					
					if(!empty($_POST['npwd']))
					{
					
						if($row['password']==$opwd)
						{
							if($npwd==$cnpwd)
							{
								mysqli_query($con,"update register 
								set password='$npwd' where id=$uid");
								if(mysqli_affected_rows($con)==1)
								{
									echo "<p>Password Changed 
									Successfully</p>";
								}
								else
								{
									echo mysqli_error($con);
								}
							}
							else
							{
								echo "<p>Passwords Does not match</p>";
							}
						}
						else
						{
							echo "<p>Old Passwrod does not match with 
							DB Password </p>";
						}
					}
					else
					{
						echo "<P>Please Fill the Passwords</p>";
					}
				}
				
				?>
				
				<form action="" method="POST">
					<table>
						<tr>
							<td>Enter Old Password</td>
							<td><input type="password" name="opwd"></td>
						</tr>
						<tr>
							<td>Enter New Password</td>
							<td><input type="password" name="npwd"></td>
						</tr>
						<tr>
							<td>Confirm New Password</td>
							<td><input type="password" name="cnpwd"></td>
						</tr>
						<tr>
							<td></td>
							<td><input type="submit" name="update" 
							value="Update"></td>
						</tr>
					</table>
				</form>
			</body>
		</html>
	<?php
}
else
{
	header("location:login.php");
}
?>