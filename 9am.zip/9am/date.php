<?php 
//date_default_timezone_set("Asia/Calcutta");
//echo date("H:i:s a");

//date_default_timezone_set("Europe/London");
//echo date("Y-m-d h:i:s a");


//echo date("w");//0,1,2,3,4,5,6

//echo date("W"); //week of the year(40 of 52 weeks)
//echo date("L");//leap year-1, 0-non-leap year


/*
$day1="1947-08-15";
$day2="1980-08-15";
*/
//1547004489
//echo time();
//echo date("l,Y-F-d h:i:s",strtotime("-10Days 2weeks -1year"));
/*$dob=strtotime("25-07-1987");
echo date("Y-m-d l",$dob);
*/
//echo date_default_timezone_get();
//date_default_timezone_set("Asia/Calcutta");
//echo date("h:i:s A");
//echo date("l,jS F Y h:i:s A");

//a-am/pm
//A-AM/PM
//S-st,nd,rd,th
//s-secodns
//i-minutes
//h-12hours format-01,02,03....10,11,12
//H-24hours Format-01,02,03....13,14,...23
//g-12hours format-1,2,3....10,11,12
//G-24hours Format-1,2,3....13,14,...23





// echo "<br>";
// echo date("d-M-Y");
// echo "<br>";
// echo date("j-M-Y");
// echo "<br>";
// echo date("D-M-Y");
// echo "<br>";
// echo date("l,dS F Y");
//always gices you the current date and time
/*echo date("d-F-Y");
echo "<br>";
echo date("d-M-Y");
echo "<br>";
echo date("d-m-Y");
echo "<br>";
echo date("d-n-Y");
*/

//echo time(); 

//1970 jan 1st


//echo date("y");

//28-09-2017

//echo date("d-m-Y");

//28-sep-2017
//echo date("d-M-Y");


//28 september 2017

//echo date("h:i:s a");
//echo date_default_timezone_get();
//date_default_timezone_set("Pacific/Auckland");
//date_default_timezone_set("Australia/Sydney");
//date_default_timezone_set("Asia/Singapore");
//echo date("Y-m-d h:i:sa");
?>









