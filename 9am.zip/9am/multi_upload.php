<html>
	<head>
		<title>Multiple File Uloading</title>
	</head>
	<body>
		<h1>Multiple File Uploading</h1>
		<?php 
		$msg=array();
		if(isset($_POST['submit']))
		{
			$c=count($_FILES['avatar']['name']);
			for($i=0;$i<$c;$i++)
			{
				if(is_uploaded_file($_FILES['avatar']['tmp_name'][$i]))
				{
					$filename=$_FILES['avatar']['name'][$i];
					$size=$_FILES['avatar']['size'][$i];
					$type=$_FILES['avatar']['type'][$i];
					$tmp=$_FILES['avatar']['tmp_name'][$i];
					
					$ext=substr($filename,strpos($filename,"."));
					$chars="abcdefghijklmnopqrstuqvwxyz1234567890";
					$file_name=substr(str_shuffle($chars),10,10)."_".time().$i.$ext;
					$arr=array("image/png","image/jpeg","image/jpg","image/gif");
					if(in_array($type,$arr))
					{
						if(move_uploaded_file($tmp,"uploads/$file_name"))
						{
							$msg[]=$_FILES['avatar']['name'][$i]." is 
							uploaded successfully";
						}
						else
						{
							echo "Sorry! Unable To Upload";
						}
					}
					else
					{
						echo "<p>".$_FILES['avatar']['name'][$i]." 
						:Please Sleect Valid IMage</p>";
					}
				}
				else
				{
					echo "Please select a File";
				}
			}
		}
		
		?>		
		<?php
			if(count($msg)>0)
			{
				
				foreach($msg as $v)
				{
					echo "<P>".$v."</P>";
				}
			}
		?>
		

		
		<form method="POST" action="" enctype="multipart/form-data">
			<table>
				<tr>
					<td><label>Upload Gallery</label></td>
					<td><input type="file" multiple="multiple" 
					name="avatar[]"></td>
				</tr>
				
				<tr>
					<td></td>
					<td><input type="submit" name="submit" 
					value="Upload"></td>
				</tr>
			</table>
		</form>
	</body>
</html>




