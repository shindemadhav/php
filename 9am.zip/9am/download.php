<?php 
//header("location:http://localhost:8080/ciapp/");
header("Content-Disposition:attachement;
filename=download.zip");
readfile("9am.zip");

?>