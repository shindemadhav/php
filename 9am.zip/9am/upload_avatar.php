<?php 
session_start();
if(isset($_SESSION['loggedin_id']))
{
	include("connect.php");
	$uid=$_SESSION['loggedin_id'];
	$res=mysqli_query($con,"select *from register 
	where id=$uid");
	$row=mysqli_fetch_assoc($res);
?>
	<html>
		<head>
			<title>Upload Avatar</title>
			<link href="css/style.css" rel="stylesheet">
		</head>
		<body>
		<?php include("menu.php"); ?>
			<h1>Upload Avatar</h1>
			<?php 
			if(isset($_POST['upload']))
			{
				if(is_uploaded_file($_FILES['avatar']['tmp_name']))
				{
					$filename=$_FILES['avatar']['name'];
					$size=$_FILES['avatar']['size'];
					$type=$_FILES['avatar']['type'];
					$tmp=$_FILES['avatar']['tmp_name'];
					
					$ext=substr($filename,strpos($filename,"."));
					$chars="abcdefghijklmnopqrstuqvwxyz1234567890";
					$file_name=substr(str_shuffle($chars),10,10)."_"
					.time().$ext;
					$arr=array("image/png","image/jpeg",
					"image/jpg","image/gif");
					if(in_array($type,$arr))
					{
						if(move_uploaded_file($tmp,"profiles/$file_name"))
						{
							
							mysqli_query($con,"update register set 
							profile_pic='$file_name' where id=$uid");
							header("location:home.php");
	
							
						}
						else
						{
							echo "Sorry! Unable To Upload";
						}
					}
					else
					{
						echo "Please Sleect Valid IMage";
					}
				}
				else
				{
					echo "Please select a File";
				}
			}
			?>
			
			<form action="" method="POST" 
			enctype="multipart/form-data">
				<input type="file" name="avatar"><br><br>
				<input type="submit" name="upload" 
				value="Upload">
			</form>
			
		</body>
	</html>
<?php	
}
else
{
	header("location:login.php");
}

?>