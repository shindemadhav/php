<?php 

$x=200;
$y=300;
//here $x and $y are global variables
function welcome()
{
	$z=$GLOBALS['x']+$GLOBALS['y'];
	echo $z;
}

welcome();
?>