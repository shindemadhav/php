<?php 

/*
$x=200;

if($x==="200")
{
	echo "Okay";
}
else
{
	echo "Sorry!";
}
*/

/*$i=10;
do
{
	echo $i;
	echo "<br>";
	$i++;
}
while($i<10);

echo "End";
*/

//Task:1 to 5
/*for($i=1;$i<=10;$i=$i+2)
{
	echo $i;
	echo "<br>";
	
}*/
/*for($k=2;$k<=20;$k=$k+2)
{
	$table=$k;
	for($i=1;$i<=10;$i++)
	{
		echo $table."*".$i."=".$table*$i;
		echo "<br>";
	}
	echo "<br>===============<br>";
}
*/

//Fibonacci Series 0 1 1 2 3 5 8 13 21....
/*$x=0;
$y=1;
for($i=1;$i<=10;$i++)
{
	$z=$x+$y;
	echo $z;
	$x=$y;
	$y=$z;
	echo "<br>";
}
*/


//Prime Numbers between 1 and 20
/*$num=20;
for($i=2;$i<=$num;$i++)
{
	for($j=2;$j<=$i;$j++)
	{
		if($i%$j==0)
		{
			break;
		}
	}
	if($i==$j)
	{
		echo $i;
		echo "<br>";
	}
}*/
//Factorial
//stars

//string polindrame

$str="PHP Training";
$k=0;
for(;@$str[$k]!="";)
{
	$k++;
}

$s="";
for($i=$k-1;$i>=0;$i--)
{
	$s.=$str{$i};
}

echo $s



















?>