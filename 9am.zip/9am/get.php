<?php 

/*$n=$_POST['username'];
$e=$_POST['email'];
$m=$_POST['mobile'];
$msg=$_POST['message'];
*/
$n=$_REQUEST['username'];
$e=$_REQUEST['email'];

echo $n,$e;

/*$n=$_GET['username'];
$e=$_GET['email'];
$m=$_GET['mobile'];
$msg=$_GET['message'];
*/
//store the data into DB

?>